#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import r2_score, mean_squared_error
from catboost import CatBoostRegressor
import matplotlib.pyplot as plt


# In[2]:


# 读取数据
data = pd.read_excel('F:/研究生文件/第一篇文章数据/张毅鹏数据汇总.xlsx')


# In[3]:


# 2. 划分数据集
X = data.drop('电压', axis=1)
y = data['电压']
X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.3, random_state=42)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, random_state=42)


# In[4]:


# 3. 定义模型和参数网格
model = CatBoostRegressor()
param_grid = {
    'depth': [3, 4, 5],
    'learning_rate': [0.1, 0.01, 0.001],
    'iterations': [100, 200, 300]
}


# In[5]:


# 4. 使用交叉验证和网格搜索确定最佳模型参数
grid_search = GridSearchCV(model, param_grid, cv=5, scoring='neg_mean_squared_error')
grid_search.fit(X_train, y_train)
best_params = grid_search.best_params_


# In[6]:


# 5. 模型训练和评估
model = CatBoostRegressor(**best_params)
model.fit(X_train, y_train, eval_set=(X_val, y_val), verbose=False)


# In[11]:


# 验证集上评估模型
y_val_pred = model.predict(X_val)
r2 = r2_score(y_val, y_val_pred)
rmse = np.sqrt(mean_squared_error(y_val, y_val_pred))

print("Validation - R²:", r2)
print("Validation - RMSE:", rmse)


# In[12]:


# 测试集上评估模型
y_test_pred = model.predict(X_test)
r2_test = r2_score(y_test, y_test_pred)
rmse_test = np.sqrt(mean_squared_error(y_test, y_test_pred))

print("Test - R²:", r2_test)
print("Test - RMSE:", rmse_test)


# In[13]:


# 验证集上的预测数据与真实数据对比图
plt.scatter(y_val, y_val_pred, color='blue', label='Predicted')
plt.plot([min(y_val), max(y_val)], [min(y_val), max(y_val)], color='red', label='Actual')
plt.xlabel('Actual')
plt.ylabel('Predicted')
plt.title('Validation Set - Actual vs Predicted')
plt.legend()
plt.show()

# 测试集上的预测数据与真实数据对比图
plt.scatter(y_test, y_test_pred, color='blue', label='Predicted')
plt.plot([min(y_test), max(y_test)], [min(y_test), max(y_test)], color='red', label='Actual')
plt.xlabel('Actual')
plt.ylabel('Predicted')
plt.title('Test Set - Actual vs Predicted')
plt.legend()
plt.show()


# In[ ]:




